#include <stdio.h>
 
int main()
{
   int a, b, c, d, e;
   float f;
 
   printf("Enter two integers\n");
   scanf("%d%d", &a, &b);
 
   c = a + b;
   d = a - b;
   e = a * b;
   f = a / (float)b;
 
   printf("Addition = %d\n", c);
   printf("Subtraction = %d\n", d);
   printf("Multiplication = %d\n", e);
   printf("Division = %.2f\n", f);
 
   return 0;
}