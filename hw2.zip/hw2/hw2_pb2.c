/* Shane Tucci
Hardware and Software Systems
Homework 2
*/

#include <stdio.h>
#include <string.h>

/*This program as is has no errors, after running it originally, it only outputs "HW2 CPEN32000!"
The for loop counts the number of chars in the string, and saves it to int i
Originally there was no printf statement for the number of chars displayed
I added a statement to show how many chars are in the string
*/

int main(int argc, char** argv) {
	int i;
	char *str = "HW2  CPEN32000!", ch;
	for (i = 0; i < strlen(str); i++)
		ch = str[i];

	printf("%s\n",str);
	printf("The number of characters is %d\n",i);
	return 0;
}
