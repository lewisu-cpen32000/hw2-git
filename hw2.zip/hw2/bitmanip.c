/* Shane Tucci
Hardware and Software Systems
Homework 2
*/

#include <stdio.h>

/* Return the nth bit of x. Assume 0 <= n <= 31 */
unsigned get_bit(unsigned x, unsigned n) {
  return x & (1 << n);
}

/* Set the nth bit of the value of x to v. Assume 0 <= n <=31, and v is 0 or 1 */
void set_bit(unsigned * x, unsigned n, unsigned v) {
  x = (x & (~(1 << n))) | (v << n);
  
}

/* Flip the nth bit of the value of x. Assume 0 <= n <= 31 */
void flip_bit(unsigned *x, unsigned n) {
  x = x ^ (1 << n);
  
}


/* testing the functions */
/* Do not change anything in this code except the values of x for a wide range of testing*/


int main() 
{
	unsigned x = 0b1001110;
	unsigned a;
	unsigned expected = 1;
	unsigned n = 1;
	unsigned out;
	unsigned v;
    printf("\nTesting get_bit()\n\n");
	
	
	a = get_bit(x, n);
    if(a!=expected) {
        printf("get_bit(0x%08x,%u): 0x%08x, expected 0x%08x\n",x,n,a,expected);
    } else {
        printf("get_bit(0x%08x,%u): 0x%08x, correct\n",x,n,a);
    }
	
	x = 0b11011;
	
	expected = 1;
    n = 3;
	
	if(a!=expected) {
        printf("get_bit(0x%08x,%u): 0x%08x, expected 0x%08x\n",x,n,a,expected);
    } else {
        printf("get_bit(0x%08x,%u): 0x%08x, correct\n",x,n,a);
    }
	
    
    
    printf("\nTesting set_bit()\n\n");
	
	x = 0b1001110;
	expected = 0b1001110;
	n = 2;
	v = 1;
	out = x;
    set_bit(&x, n, v);
    if(x!=expected) {
        printf("set_bit(0x%08x,%u,%u): 0x%08x, expected 0x%08x\n",out,n,v,x,expected);
    } else {
        printf("set_bit(0x%08x,%u,%u): 0x%08x, correct\n",out,n,v,x);
    }
	
	
	x = 0b1001110;
	expected = 0b1001001110;
	n = 9;
	v = 1;
	out = x;
    set_bit(&x, n, v);
    if(x!=expected) {
        printf("set_bit(0x%08x,%u,%u): 0x%08x, expected 0x%08x\n",out,n,v,x,expected);
    } else {
        printf("set_bit(0x%08x,%u,%u): 0x%08x, correct\n",out,n,v,x);
    }
	
	
	
    
    printf("\nTesting flip_bit()\n\n");
	
	x = 0b1001110;
	expected = 0b1001010;
	n = 2;
	
	out = x;
	
	flip_bit(&x, n);
    if(x!=expected) {
        printf("flip_bit(0x%08x,%u): 0x%08x, expected 0x%08x\n",out,n,x,expected);
    } else {
        printf("flip_bit(0x%08x,%u): 0x%08x, correct\n",out,n,x);
    } 
	
	x = 0b1001110;
	expected = 0b1001001110;
	n = 9;
	
	out = x;
	
	flip_bit(&x, n);
    if(x!=expected) {
        printf("flip_bit(0x%08x,%u): 0x%08x, expected 0x%08x\n",out,n,x,expected);
    } else {
        printf("flip_bit(0x%08x,%u): 0x%08x, correct\n",out,n,x);
    } 
	
	
    
    return 0;
}